// Generated configuration for the Android Firebase app registered by the user.
// iOS/Web options must be generated separately with `flutterfire configure`.
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform => android;

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyBQ0Iz6dxDz81Ep-9nbTR7rpy1GwPV-vDg',
    appId: '1:700402094669:android:248d4c2b8175052962c204',
    messagingSenderId: '700402094669',
    projectId: 'greengold-veggies',
    storageBucket: 'greengold-veggies.firebasestorage.app',
  );
}
