import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const GreenGoldApp());
}

class GreenGoldApp extends StatelessWidget {
  const GreenGoldApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'GreenGold Veggies',
    theme: ThemeData(colorSchemeSeed: const Color(0xFF176B3A), useMaterial3: true),
    home: const AuthGate(),
  );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, auth) {
        if (auth.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        if (!auth.hasData) return const PhoneLoginPage();
        return RoleHome(uid: auth.data!.uid);
      },
    );
  }
}

class PhoneLoginPage extends StatefulWidget {
  const PhoneLoginPage({super.key});
  @override
  State<PhoneLoginPage> createState() => _PhoneLoginPageState();
}

class _PhoneLoginPageState extends State<PhoneLoginPage> {
  final phone = TextEditingController();
  final otp = TextEditingController();
  String? verificationId;
  String message = '';
  bool busy = false;

  Future<void> sendOtp() async {
    setState(() { busy = true; message = ''; });
    await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: phone.text.trim(),
      verificationCompleted: (credential) async {
        await FirebaseAuth.instance.signInWithCredential(credential);
      },
      verificationFailed: (e) => setState(() { message = e.message ?? 'OTP failed'; busy = false; }),
      codeSent: (id, token) => setState(() { verificationId = id; message = 'OTP sent'; busy = false; }),
      codeAutoRetrievalTimeout: (id) => verificationId = id,
    );
  }

  Future<void> verifyOtp() async {
    if (verificationId == null) return;
    setState(() => busy = true);
    try {
      final credential = PhoneAuthProvider.credential(
        verificationId: verificationId!, smsCode: otp.text.trim());
      await FirebaseAuth.instance.signInWithCredential(credential);
    } catch (e) {
      setState(() { message = 'Could not verify OTP. Check the code and try again.'; busy = false; });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('GreenGold Veggies')),
    body: Padding(padding: const EdgeInsets.all(20), child: Column(
      mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.local_grocery_store, size: 64, color: Color(0xFF176B3A)),
        TextField(controller: phone, keyboardType: TextInputType.phone,
          decoration: const InputDecoration(labelText: 'Phone number (+91...)')),
        if (verificationId != null) TextField(controller: otp, keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'OTP')),
        const SizedBox(height: 16),
        FilledButton(onPressed: busy ? null : (verificationId == null ? sendOtp : verifyOtp),
          child: Text(busy ? 'Please wait...' : (verificationId == null ? 'Send OTP' : 'Verify OTP'))),
        Text(message),
      ],
    )),
  );
}

class RoleHome extends StatelessWidget {
  final String uid;
  const RoleHome({super.key, required this.uid});
  @override
  Widget build(BuildContext context) => StreamBuilder<DocumentSnapshot<Map<String,dynamic>>>(
    stream: FirebaseFirestore.instance.collection('users').doc(uid).snapshots(),
    builder: (context, snap) {
      if (!snap.hasData) return const Scaffold(body: Center(child:CircularProgressIndicator()));
      final data = snap.data!.data() ?? {};
      final role = data['role'] ?? 'customer';
      if (!snap.data!.exists) {
        FirebaseFirestore.instance.collection('users').doc(uid).set({
          'role':'customer','createdAt':FieldValue.serverTimestamp()
        });
      }
      return Scaffold(
        appBar: AppBar(title: Text('GreenGold Veggies • $role'),
          actions: [IconButton(onPressed: () => FirebaseAuth.instance.signOut(),
            icon: const Icon(Icons.logout))]),
        body: role == 'admin' ? const AdminHome() :
          role == 'rider' ? const RiderHome() : const CustomerHome(),
      );
    },
  );
}

class CustomerHome extends StatelessWidget {
  const CustomerHome({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(
    stream: FirebaseFirestore.instance.collection('products')
      .where('active', isEqualTo: true).snapshots(),
    builder: (context, snap) {
      if (snap.hasError) return Center(child: Text('Error: \${snap.error}'));
      if (!snap.hasData) return const Center(child:CircularProgressIndicator());
      if (snap.data!.docs.isEmpty) return const Center(child:Text('Products will appear here soon.'));
      return ListView(children: snap.data!.docs.map((d) {
        final p=d.data();
        return ListTile(title:Text('\${p['name'] ?? 'Product'}'),
          subtitle:Text('\${p['unit'] ?? ''}'),
          trailing:Text('₹\${p['price'] ?? '-'}'));
      }).toList());
    },
  );
}

class AdminHome extends StatelessWidget {
  const AdminHome({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(
    stream: FirebaseFirestore.instance.collection('orders')
      .orderBy('createdAt', descending:true).snapshots(),
    builder: (context,snap) {
      if (!snap.hasData) return const Center(child:CircularProgressIndicator());
      return ListView(children: [
        const ListTile(title:Text('Admin • Orders')),
        ...snap.data!.docs.map((d) => ListTile(
          title:Text('Order \${d.id}'),
          subtitle:Text('\${d.data()['orderStatus'] ?? 'placed'} • ₹\${d.data()['total'] ?? '-'}'),
        ))
      ]);
    },
  );
}

class RiderHome extends StatelessWidget {
  const RiderHome({super.key});
  @override
  Widget build(BuildContext context) => const Center(
    child: Text('Delivery team: assigned orders will appear here after secure rider assignment is configured.'),
  );
}
