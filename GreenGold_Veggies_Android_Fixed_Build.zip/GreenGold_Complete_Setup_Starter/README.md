# GreenGold Veggies — Complete Firebase MVP scaffold

## What this package provides
- Flutter single-codebase starter with phone OTP authentication.
- Role-based customer/admin/rider home routing.
- Firestore product and order views.
- Firestore security rules using trusted Firebase custom claims.
- Cloud Functions for admin-controlled role assignment and rider assignment.

This is a development scaffold, not a finished production app. The rider screen is a placeholder; cart/checkout UI, live map tracking, push notifications, payment gateway integration, and complete admin product management still need implementation and testing.

## Firebase setup
1. The supplied Firebase config is already placed at `android/app/google-services.json`. It matches the Firebase registration ID `Com.greengold.veggies`.
2. Install Flutter SDK, Node.js 20+, Firebase CLI and FlutterFire CLI.
3. Run `flutter pub get`.
4. Run `dart pub global activate flutterfire_cli`.
5. Run `flutterfire configure` and select your existing GreenGold Firebase project and Android/iOS platforms. This generates `lib/firebase_options.dart`.
6. In Firebase Console enable Authentication > Phone and create Cloud Firestore.
7. Deploy reviewed rules: `firebase deploy --only firestore:rules`.
8. In `functions/`, run `npm install` then `npm run build`; from project root deploy functions with `firebase deploy --only functions`.

## Critical first-admin setup
Do not let users choose their own admin role. Create the first admin custom claim only from a trusted, private Admin SDK environment controlled by you/your developer. Never paste service-account keys into chat. After claims are changed, sign out and sign in again to refresh the ID token.

## Suggested Firestore documents
`products/{productId}`: name, teluguName, category, price, unit, imageUrl, stockQty, active.
`users/{uid}`: name, phone, role (customer/rider/admin; role must be set by trusted admin process).
`orders/{orderId}`: customerId, items, total, address, phone, deliveryType, paymentMethod, paymentStatus, orderStatus, riderId, createdAt, updatedAt.

## Payments
UPI must be processed through Razorpay or another approved gateway. Create orders and verify payment signatures/webhooks on a trusted server. Never store gateway secrets in Flutter or Firestore, and never request a UPI PIN.

## Android application ID
The uploaded Firebase registration uses this exact Android package name (applicationId): `Com.greengold.veggies` (capital C). Android package IDs are case-sensitive, so use this exact spelling in the Android Gradle applicationId to match the uploaded Firebase registration. If you prefer `com.greengold.veggies` (lowercase c), register a separate Android app in Firebase with that exact lowercase ID and download its matching JSON file.

## Android / iOS
This folder includes the Android location for `google-services.json`. iOS also needs the generated `GoogleService-Info.plist`, Xcode bundle/signing configuration, and a Mac to build/sign an IPA.

## Android project files included
This archive now includes Android Gradle/Kotlin project files and an Android Firebase options file for the uploaded registration. The Firebase Android application ID is `Com.greengold.veggies` (capital C), matching the uploaded JSON. The Kotlin namespace remains lowercase `com.greengold.veggies`.

## Build an APK
1. Install Flutter stable, Android Studio, Android SDK Platform 35, and JDK 17.
2. Open this project folder in Android Studio, or run `flutter pub get` from this folder.
3. Run `flutter build apk --debug` for a test APK, or `flutter build apk --release` after completing production setup.
4. The APK is normally created at `build/app/outputs/flutter-apk/`.

This environment did not compile or device-test the APK. Phone OTP requires enabling Phone sign-in in Firebase Authentication and configuring allowed test/real numbers. Firestore rules and role claims must be deployed securely before live use. This is not yet a production-ready shopping app: cart, checkout, payment gateway verification, rider assignment UI, push notifications, and full admin inventory workflows remain to be implemented.
