import {onCall, HttpsError} from 'firebase-functions/v2/https';
import {initializeApp} from 'firebase-admin/app';
import {getAuth} from 'firebase-admin/auth';
import {getFirestore, FieldValue} from 'firebase-admin/firestore';

initializeApp();
const db = getFirestore();

// Callable by an existing trusted administrator only.
// Set initial admin custom claim manually using a secure Admin SDK environment.
export const setUserRole = onCall(async (request) => {
  if (!request.auth || request.auth.token.admin !== true) {
    throw new HttpsError('permission-denied', 'Admin access required');
  }
  const {uid, role} = request.data as {uid: string, role: 'admin'|'rider'|'customer'};
  if (!uid || !['admin','rider','customer'].includes(role)) {
    throw new HttpsError('invalid-argument', 'Valid uid and role required');
  }
  await getAuth().setCustomUserClaims(uid, {
    admin: role === 'admin', rider: role === 'rider'
  });
  await db.collection('users').doc(uid).set({role, updatedAt:FieldValue.serverTimestamp()}, {merge:true});
  return {ok:true};
});

// Admin-only order assignment; rider can then read only their assigned orders.
export const assignRider = onCall(async (request) => {
  if (!request.auth || request.auth.token.admin !== true) {
    throw new HttpsError('permission-denied', 'Admin access required');
  }
  const {orderId, riderUid} = request.data as {orderId:string, riderUid:string};
  if (!orderId || !riderUid) throw new HttpsError('invalid-argument', 'orderId and riderUid required');
  const rider = await getAuth().getUser(riderUid);
  if (rider.customClaims?.rider !== true) throw new HttpsError('failed-precondition', 'User is not a rider');
  await db.collection('orders').doc(orderId).update({
    riderId:riderUid, orderStatus:'assigned', updatedAt:FieldValue.serverTimestamp()
  });
  return {ok:true};
});
