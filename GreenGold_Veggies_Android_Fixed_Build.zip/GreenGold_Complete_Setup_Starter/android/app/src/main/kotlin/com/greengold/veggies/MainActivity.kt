package com.greengold.veggies

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
