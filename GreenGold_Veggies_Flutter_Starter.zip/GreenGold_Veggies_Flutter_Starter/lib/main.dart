import 'package:flutter/material.dart';

void main() => runApp(const GreenGoldApp());

const green = Color(0xFF176B3A);
const gold = Color(0xFFE5B83B);

class GreenGoldApp extends StatelessWidget {
  const GreenGoldApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'GreenGold Veggies',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: green),
      scaffoldBackgroundColor: const Color(0xFFF6F8F4), useMaterial3: true),
    home: const ShopPage(),
  );
}

class Product {
  final int id; final String name, telugu, unit, emoji, category; final int price;
  const Product(this.id,this.name,this.telugu,this.unit,this.emoji,this.category,this.price);
}
const products = [
  Product(1,'Tomato','టమాటా','1 kg','🍅','Vegetables',30),
  Product(2,'Onion','ఉల్లిపాయ','1 kg','🧅','Vegetables',35),
  Product(3,'Potato','బంగాళాదుంప','1 kg','🥔','Vegetables',32),
  Product(4,'Carrot','క్యారెట్','1 kg','🥕','Vegetables',45),
  Product(5,'Cucumber','దోసకాయ','1 kg','🥒','Vegetables',30),
  Product(6,'Banana','అరటిపండ్లు','1 dozen','🍌','Fruits',50),
  Product(7,'Apple','ఆపిల్','1 kg','🍎','Fruits',140),
  Product(8,'Orange','నారింజ','1 kg','🍊','Fruits',80),
  Product(9,'Grapes','ద్రాక్ష','1 kg','🍇','Fruits',90),
];

class ShopPage extends StatefulWidget {
  const ShopPage({super.key});
  @override State<ShopPage> createState()=>_ShopPageState();
}
class _ShopPageState extends State<ShopPage> {
  final Map<int,int> cart = {};
  String category='All', address='Thumkunta, Hyderabad';
  int get count=>cart.values.fold(0,(a,b)=>a+b);
  int get total=>products.fold(0,(a,p)=>a+p.price*(cart[p.id]??0));
  void change(Product p,int delta) => setState(() {
    final next=(cart[p.id]??0)+delta;
    if(next<=0) {cart.remove(p.id);} else {cart[p.id]=next;}
  });
  @override Widget build(BuildContext context) {
    final shown=products.where((p)=>category=='All'||p.category==category).toList();
    return Scaffold(
      appBar: AppBar(backgroundColor: green,foregroundColor: Colors.white,
        title: const Row(children:[Text('🌿 '),Text('GreenGold Veggies',style:TextStyle(fontWeight:FontWeight.bold))]),
        actions:[IconButton(onPressed:()=>showCart(),icon:Badge(label:Text('$count'),child:const Icon(Icons.shopping_cart)))],
      ),
      body: ListView(padding: const EdgeInsets.all(14), children:[
        Card(color:green,child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Text('Freshness at Your Doorstep',style:TextStyle(color:Colors.white,fontSize:19,fontWeight:FontWeight.bold)),
          const SizedBox(height:8),const Text('తాజా కూరగాయలు • పండ్లు • మీ ఇంటికే',style:TextStyle(color:Colors.white)),
          const SizedBox(height:14),TextField(controller:TextEditingController(text:address),
            onChanged:(v)=>address=v,decoration:const InputDecoration(filled:true,fillColor:Colors.white,
            prefixIcon:Icon(Icons.location_on),labelText:'Delivery address',border:OutlineInputBorder())),
        ]))),
        const SizedBox(height:8),
        Wrap(spacing:8,children:['All','Vegetables','Fruits'].map((c)=>ChoiceChip(
          label:Text(c),selected:category==c,onSelected:(_)=>setState(()=>category=c))).toList()),
        const Padding(padding:EdgeInsets.symmetric(vertical:12),child:Text('Fresh products',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold))),
        GridView.builder(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),
          itemCount:shown.length,gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount:2,childAspectRatio:.83,crossAxisSpacing:10,mainAxisSpacing:10),
          itemBuilder:(context,i){final p=shown[i];final q=cart[p.id]??0;return Card(
            child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
              Expanded(child:Center(child:Text(p.emoji,style:const TextStyle(fontSize:48)))),
              Text(p.name,style:const TextStyle(fontWeight:FontWeight.bold)),
              Text('${p.telugu} • ${p.unit}',style:const TextStyle(fontSize:11,color:Colors.grey)),
              Text('₹${p.price}',style:const TextStyle(fontWeight:FontWeight.bold,fontSize:17)),
              const SizedBox(height:6),
              if(q==0) SizedBox(width:double.infinity,child:FilledButton(onPressed:()=>change(p,1),child:const Text('ADD +')))
              else Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
                IconButton(onPressed:()=>change(p,-1),icon:const Icon(Icons.remove_circle_outline)),
                Text('$q',style:const TextStyle(fontWeight:FontWeight.bold)),
                IconButton(onPressed:()=>change(p,1),icon:const Icon(Icons.add_circle,color:green)),
              ])
            ])));
          }),
        const SizedBox(height:12),
        FilledButton.icon(onPressed:count==0?null:showCart,icon:const Icon(Icons.shopping_bag),
          label:Text('View cart • $count items • ₹$total'),style:FilledButton.styleFrom(backgroundColor:green,padding:const EdgeInsets.all(15))),
        const SizedBox(height:18),const Center(child:Text('Customer Support: 7893857505',style:TextStyle(color:green,fontWeight:FontWeight.bold))),
        const Center(child:Text('Thumkunta & Shamirpet',style:TextStyle(color:Colors.grey))),
      ]),
    );
  }
  void showCart() {
    showModalBottomSheet(context:context,isScrollControlled:true,builder:(ctx)=>StatefulBuilder(
      builder:(ctx,setSheet)=>Padding(padding:EdgeInsets.fromLTRB(18,18,18,MediaQuery.of(ctx).viewInsets.bottom+24),
        child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Text('Your Cart',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
          if(count==0) const Padding(padding:EdgeInsets.all(20),child:Text('Your cart is empty')),
          ...products.where((p)=>(cart[p.id]??0)>0).map((p)=>ListTile(
            leading:Text(p.emoji,style:const TextStyle(fontSize:28)),title:Text(p.name),
            subtitle:Text('₹${p.price} × ${cart[p.id]}'),trailing:Text('₹${p.price*cart[p.id]!}'))),
          const Divider(),ListTile(title:const Text('Total',style:TextStyle(fontWeight:FontWeight.bold)),
            trailing:Text('₹$total',style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold,color:green))),
          SizedBox(width:double.infinity,child:FilledButton(onPressed:count==0?null:(){
            Navigator.pop(ctx); Navigator.push(context,MaterialPageRoute(builder:(_)=>CheckoutPage(total:total,address:address)));
          },child:const Text('Continue to checkout')))
        ]))));
  }
}

class CheckoutPage extends StatefulWidget {
  final int total; final String address;
  const CheckoutPage({super.key,required this.total,required this.address});
  @override State<CheckoutPage> createState()=>_CheckoutPageState();
}
class _CheckoutPageState extends State<CheckoutPage> {
  String delivery='Express (30-minute target)',payment='UPI';
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Checkout')),
    body:ListView(padding:const EdgeInsets.all(18),children:[
      const Text('Delivery address',style:TextStyle(fontWeight:FontWeight.bold)),
      ListTile(leading:const Icon(Icons.location_on,color:green),title:Text(widget.address)),
      const SizedBox(height:12),const Text('Delivery option',style:TextStyle(fontWeight:FontWeight.bold)),
      RadioListTile(value:'Express (30-minute target)',groupValue:delivery,title:const Text('Express delivery'),onChanged:(v)=>setState(()=>delivery=v!)),
      RadioListTile(value:'Same-day delivery',groupValue:delivery,title:const Text('Same-day delivery'),onChanged:(v)=>setState(()=>delivery=v!)),
      const SizedBox(height:12),const Text('Payment method',style:TextStyle(fontWeight:FontWeight.bold)),
      RadioListTile(value:'UPI',groupValue:payment,title:const Text('UPI'),onChanged:(v)=>setState(()=>payment=v!)),
      RadioListTile(value:'Cash on Delivery',groupValue:payment,title:const Text('Cash on Delivery'),onChanged:(v)=>setState(()=>payment=v!)),
      const Card(child:Padding(padding:EdgeInsets.all(14),child:Text('UPI ID provided: 7893857505@pthdfc\nLive payment gateway is not connected in this starter app.',style:TextStyle(fontSize:12)))),
      ListTile(title:const Text('Order total'),trailing:Text('₹${widget.total}',style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold,color:green))),
      FilledButton(onPressed:()=>showDialog(context:context,builder:(_)=>AlertDialog(
        title:const Text('Demo checkout'),content:Text('Total: ₹${widget.total}\\nDelivery: $delivery\\nPayment: $payment\\n\\nThis is a prototype. No real order or payment was submitted.'),
        actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('OK'))])),child:const Text('Review demo order'))
    ]),
  );
}
