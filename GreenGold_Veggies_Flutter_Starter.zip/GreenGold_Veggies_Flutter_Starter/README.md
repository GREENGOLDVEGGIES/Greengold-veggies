# GreenGold Veggies — Flutter Starter

This is a Flutter customer-app starter source for Android and iOS.

## Included
- GreenGold Veggies branding
- Product listing: vegetables and fruits
- Category filters
- Add/remove cart quantities and totals
- Checkout screen
- Express / same-day delivery selection
- UPI / Cash on Delivery selection
- Support number and delivery area

## Run
Install Flutter SDK, then from this folder:
```bash
flutter pub get
flutter run
```
To build:
```bash
flutter build apk
flutter build appbundle
flutter build ios
```
iOS builds require macOS and Xcode.

## Not production-ready yet
No backend, customer authentication, live inventory, admin dashboard, rider app, order database, notifications, maps, or payment gateway is connected. The UPI ID is displayed as information only. Do not collect UPI PINs in the app. Connect a secure backend and a payment provider before accepting real orders. Also verify business registrations, tax and food-safety requirements with a qualified professional.
